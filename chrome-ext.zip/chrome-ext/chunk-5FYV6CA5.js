import{a}from"./chunk-E7ZOKENL.js";import"./chunk-BHCM4M3W.js";export{a as startFocusVisible};
