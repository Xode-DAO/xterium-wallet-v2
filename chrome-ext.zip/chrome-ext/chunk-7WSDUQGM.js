import{b as a,c as b}from"./chunk-M2X7KQLB.js";import"./chunk-BHCM4M3W.js";export{a as GESTURE_CONTROLLER,b as createGesture};
