var e=r=>r&&r.dir!==""?r.dir.toLowerCase()==="rtl":document?.dir.toLowerCase()==="rtl";export{e as a};
