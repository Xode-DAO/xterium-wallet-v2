import{b as o}from"./chunk-CW5S43N5.js";var n=o("LocalNotifications",{web:()=>import("./chunk-Z42KCQQV.js").then(r=>new r.LocalNotificationsWeb)});export{n as a};
