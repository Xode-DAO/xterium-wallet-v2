import{b as e}from"./chunk-CW5S43N5.js";var t=e("Preferences",{web:()=>import("./chunk-ZF77SUNE.js").then(r=>new r.PreferencesWeb)});export{t as a};
