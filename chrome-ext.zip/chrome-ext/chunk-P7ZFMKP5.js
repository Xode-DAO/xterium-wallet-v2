import{d as s}from"./chunk-URLTP6TX.js";var t=class{constructor(){this.id="-",this.name="-",this.chain=new s,this.mnemonic_phrase="-",this.public_key="-",this.private_key="-"}};export{t as a};
